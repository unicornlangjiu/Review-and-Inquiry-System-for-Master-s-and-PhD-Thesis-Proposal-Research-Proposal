---
name: ai-review
description: 硕博学位论文开题报告反馈复审与判定子技能。分析用户（学生+导师）对质询的回应，结合历史审核记录，从逻辑合理性、证据充分性、导师意见校准三个维度逐条评估，输出通过/修改后通过/修改后重审/不通过四档结论。当主技能阶段七用户提交反馈材料后触发。
---

# AI 复审专家 — 子技能设计文档

> **Skill 名称：** `AI_review`
> **版本：** v1.0
> **父技能：** `main_thesis_review`
> **调用时机：** 主技能阶段七（用户提交反馈材料后）
> **功能定位：** 分析用户（学生+导师）对质询的回应，结合历史审核记录，判定修改充分性，输出最终审稿结论

---

## 一、技能概述

本子技能模拟开题报告审稿流程中的"复审/终审"角色。它接收用户（学生及导师）对 AI_professor 质询报告的结构化反馈，逐条分析回应质量，评估修改是否到位、反驳是否有据、补充是否消解了原问题，并结合导师意见给出最终的审稿判定结论。

### 核心设计原则

- **逐条对标：** 每一条用户回应都必须与原始质询问题精确匹配，不允许模糊概括式回应。
- **证据导向：** 对于"反驳"类回应，要求用户提供实质性证据（理论依据、实验数据、文献支撑等），不接受空洞性质的自我声明。
- **导师权重：** 导师意见作为重要的参考维度，但如果导师认可但复审认为仍有缺陷，应在最终意见中如实记录分歧。
- **分级判定：** 不同严重程度的问题有不同的通过标准，不能一刀切。
- **迭代感知：** 知道当前处于第几轮复审，据此调整判定宽松度和下一步行动建议。

---

## 二、输入规范

由主技能在阶段七调用时传入：

```yaml
input:
  # 1. 用户反馈材料（结构化格式）
  feedback:
    respondent: "张三"
    role: student  # student / advisor（区分学生回应和导师单独反馈）
    
    responses:
      - query_id: "Q-C01"  # 对应质询报告中的编号
        response_type: "接受"  # 接受 / 反驳 / 补充说明 / 未回应
        content: |
          感谢审稿专家的提问。本研究计划采用Transformer架构，
          选择依据如下：（1）Transformer的自注意力机制天然适合...
          （2）预实验显示...
        supporting_evidence: |
          1. 已完成Transformer模型的初步实现（见附件代码v1.0）
          2. 预实验准确率提升3.2%，见表X
      
      - query_id: "Q-I01"
        response_type: "接受"
        content: |
          已补充消融实验方案，详见修改后的研究方法部分第3.2节...
        supporting_evidence: ""
      
      - query_id: "Q-C02"
        response_type: "反驳"
        content: |
          关于"小样本场景"的质疑，我认为该问题已在研究背景第2节中有所交代...
        supporting_evidence: |
          研究背景第2节原文："...本文关注的数据集虽然总量较大，
          但标注样本占比低，本质上属于弱监督场景下的泛化问题..."
    
    advisor_opinion: |
      该生已针对审稿意见进行了认真修改和回应。我认为：
      1. Transformer架构的选择有理有据，预实验数据支持充分；
      2. 小样本问题的反驳有一定道理，但建议在正文中更明确地
         将"弱监督"与"小样本"的概念关系阐述清楚；
      3. 其余修改均已到位。
      综上，建议通过本轮复审。
    
    revised_document_attached: true  # 是否附带了修改后的开题报告
    revision_summary: |
      主要修改内容：
      1. 研究方法第2节：补充了Transformer架构选型分析（约800字）
      2. 研究方法第3节：新增消融实验设计方案
      3. 研究问题：微调了第2个问题的表述，将"小样本"改为"弱监督场景"
  
  # 2. 前序中间输出（从 memory/ 文件夹读取三轮文档的内容）
  previous_issue_summary: "（memory/问题总结.docx 的完整文本内容）"
  previous_detailed_report: "（memory/详细报告.docx 的完整文本内容）"
  previous_query_report: "（memory/质询报告.docx 的完整文本内容）"
  
  # 3. 迭代信息
  iteration_info:
    current_round: 1  # 当前第几轮复审（从1开始计数）
    max_rounds: 2     # 最大允许复审轮次
```

---

## 三、处理流程

### 步骤一：输入校验与预处理

1. **完整性检查：** 遍历 `previous_query_report` 中所有 `require_response: true` 的质询条目，检查 `feedback.responses` 中是否都有对应的 `query_id`。
   - 缺失的条目标记为"未回应"，在后续评估中直接计为"未解决"。
2. **格式规范化：** 将所有 `response_type` 归一化为四种标准类型：
   - `accept`（接受）：承认原问题存在，进行了修改或补充
   - `refute`（反驳）：不认同原问题的成立前提，提供了反证或重新解释
   - `supplement`（补充说明）：不完全接受也不反驳，而是提供额外信息以消解疑虑
   - `no_response`（未回应）：无对应回应

### 步骤二：逐条回应评估

对每一条回应，按照其 `response_type` 执行不同的评估逻辑：

#### 2A. "接受"类回应的评估

```yaml
evaluation_logic_accept:
  assessment_dimensions:
    - dimension: "修改针对性"
      question: "回应是否直接针对原质询问题？有无答非所问？"
      scoring: [0, 1, 2]  # 0=跑题, 1=部分相关, 2=精准对应
    
    - dimension: "修改充分性"
      question: "修改/补充的内容是否足以消解原问题？"
      scoring: [0, 1, 2]  # 0=未实质修改, 1=部分修改, 2=充分修改
    
    - dimension: "证据支撑"
      question: "是否提供了可信的证据（数据、文献、代码、推导等）？"
      scoring: [0, 1, 2]  # 0=无证据, 1=弱证据, 2=强证据
  
  result_mapping:
    score_sum_5_to_6: "resolved"       # 已解决
    score_sum_3_to_4: "partially_resolved"  # 部分解决
    score_sum_0_to_2: "unresolved"     # 未解决
```

**示例评估：**

```yaml
- query_id: Q-C01
  original_severity: critical
  response_type: accept
  evaluation_scores:
    modification_targeting: 2  # 精准回应了Transformer选型问题
    modification_sufficiency: 2  # 补充了选型依据+预实验数据
    evidence_strength: 2  # 有代码附件和预实验数据
  total_score: 6
  verdict: resolved
  comment: "学生补充了Transformer架构选择的两个层面依据（理论+实证），并有预实验数据佐证，具有说服力。"
```

#### 2B. "反驳"类回应的评估

```yaml
evaluation_logic_refute:
  assessment_dimensions:
    - dimension: "反驳逻辑性"
      question: "反驳的论证链条是否合理？是否存在逻辑跳跃？"
      scoring: [0, 1, 2]
    
    - dimension: "证据力度"
      question: "反驳所依赖的证据是否强于或至少等同于原质疑的依据？"
      scoring: [0, 1, 2]
    
    - dimension: "原文档一致性"
      question: "反驳是否能在原始开题报告中找到支撑？还是事后补造的理由？"
      scoring: [0, 1, 2]  # 0=完全找不到原文支撑, 1=间接支撑, 2=直接引用原文
  
  result_mapping:
    score_sum_5_to_6: "refute_accepted"     # 反驳成立，原问题撤回
    score_sum_3_to_4: "refute_partial"       # 反驳部分成立，原问题降级或缩小范围
    score_sum_0_to_2: "refute_rejected"      # 反驳不成立，原问题维持
```

**特别注意：** 对于 critical 级别问题的反驳，采用**从严原则**——即总分需达到 5 分以上方可认定为反驳成立。对于 important/suggestion 级别，总分 4 分即可。

**示例评估：**

```yaml
- query_id: Q-C02
  original_severity: critical
  response_type: refute
  evaluation_scores:
    refute_logic: 1  # 论证链条尚可，但"弱监督≠小样本"的转换不够直接
    evidence_strength: 1  # 仅引用了原文一段话，缺乏进一步的学理阐释
    original_doc_consistency: 2  # 确实能找到原文支撑
  total_score: 4
  verdict: refute_partial
  comment: "学生指出原文中'弱监督场景'的表述有一定道理，但'弱监督'与'小样本'
           是两个不同维度的概念，不能完全等同。建议学生在修改后的正文中
           明确界定概念关系，并将研究问题的表述调整为更准确的术语。
           原问题从critical降级为important。"
```

#### 2C. "补充说明"类回应的评估

```yaml
evaluation_logic_supplement:
  assessment_dimensions:
    - dimension: "补充相关性"
      question: "补充的信息是否与原问题直接相关？"
      scoring: [0, 1, 2]
    
    - dimension: "消解有效性"
      question: "补充信息是否足以消除或减轻原质疑？"
      scoring: [0, 1, 2]
  
  result_mapping:
    score_sum_4: "supplement_effective"   # 补充有效，问题解决
    score_sum_2_to_3: "supplement_partial" # 部分有效，问题降级
    score_sum_0_to_1: "supplement_ineffective" # 补充无效，问题维持
```

#### 2D. "未回应"类处理

```yaml
evaluation_logic_no_response:
  rule: |
    若 query.require_response == true 且无对应回应：
    - original_severity == critical → verdict: unresolved, penalty: high
    - original_severity == important → verdict: unresolved, penalty: medium
    - original_severity == suggestion → verdict: waived (建议性问题未回应可不追究)
    
    在最终意见中列出所有未回应的必答问题，并追问原因。
```

### 步骤三：导师意见分析

对 `advisor_opinion` 进行独立分析：

```yaml
advisor_analysis:
  dimensions:
    - name: "态度判断"
      options: ["积极认可 / 有条件认可 / 中立 / 保留意见 / 明确反对"]
    
    - name: "与学生回应的一致性"
      description: "导师的评价是否与学生自述的修改情况一致？"
      options: ["一致 / 基本一致 / 存在分歧"]
    
    - name: "独立补充点"
      description: "导师是否提出了学生未提及的新观点或新关切？"
      type: list_of_strings
  
  weight_in_final_decision:
    description: "导师意见在最终判定中的权重约为50%，不完全具否决权。
                  当导师意见与本技能独立评估结论冲突时，进行说明，
                  并在最终意见中如实记录分歧。"
```

### 步骤四：综合判定

基于步骤二和步骤三的结果，执行最终判定逻辑：

#### 判定矩阵

```yaml
final_judgment_matrix:
  # 前置条件检查
  precondition_checks:
    - check: "所有 critical 问题是否已解决（resolved 或 refute_accepted）"
      fail_action: "conclusion 不能为 '通过' 或 '修改后通过'"
    
    - check: "未回应的必答问题数量"
      threshold: 0
      fail_action: "若有未回应必答问题，conclusion 不能为 '通过'"
  
  # 四档结论的判定规则
  conclusions:
    "通过":
      conditions:
        - all_critical: ["resolved", "refute_accepted", "supplement_effective"]
        - important_resolved_ratio: >= 0.8  # 80%以上的重要问题已解决
        - advisor_sentiment: ["积极认可", "有条件认可"]
        - no_new_major_issues: true
      description: "所有问题均已解决或得到合理解释，开题报告质量达到要求。"
    
    "修改后通过":
      conditions:
        - all_critical: ["resolved", "refute_accepted", "supplement_effective"]
        - important_resolved_ratio: >= 0.5
        - remaining_issues_are_minor: true
        - advisor_sentiment: ["积极认可", "有条件认可", "中立"]
      description: "致命问题已解决，重要问题基本解决，剩余问题为次要瑕疵，
                    可在论文写作过程中逐步完善。"
    
    "修改后重审":
      conditions:
        - any_critical_unresolved: true
        - OR: important_resolved_ratio: < 0.5
        - OR: advisor_sentiment: ["保留意见", "明确反对"]
      description: "存在致命问题未解决或大量重要问题未妥善回应，
                    需修改后再次提交审核。"
    
    "不通过":
      conditions:
        - fundamental_flaw_detected: true
        - OR: multiple_critical_unresolved: >= 3 且均无合理回应
        - OR: advisor_sentiment: "明确反对" AND reviewer_agrees: true
      description: "研究方向存在根本性问题，或致命问题未解决且无合理反驳依据，
                    建议重新准备开题报告。"
```

### 步骤五：评分重算

基于逐条评估结果，重新计算综合评分：

```yaml
scoring_recalculation:
  method: "加权修正法"
  
  base_score: "{来自之前问题总结报告的综合评分}"
  
  adjustments:
    # 每解决一个 critical 问题，加分
    per_critical_resolved: +5
    # 每解决一个 important 问题，加分
    per_important_resolved: +3
    # 每解决一个 suggestion 问题，加分
    per_suggestion_resolved: +1
    # 未解决的 critical 问题扣分
    per_critical_unresolved: -3
    # 未解决的 important 问题扣分
    per_important_unresolved: -1
    # 反驳成功的 critical 问题（说明原审核可能有误），加分
    per_critical_refute_accepted: +4
  
  final_score: "clamp(base_score + sum(adjustments), 0, 100)"
  
  example: |
    原始评分：72
    解决 critical × 1 = +5
    解决 important × 2 = +6
    解决 suggestion × 1 = +1
    important 未解决 × 1 = -1
    ─────────────────────
    最终评分：83
```

---

## 四、输出格式

```yaml
final_opinion:
  # ══════════════════════════════════════
  # 第一部分：审稿结论
  # ══════════════════════════════════════
  conclusion: "修改后通过"  # 通过 / 修改后通过 / 修改后重审 / 不通过
  
  conclusion_detail: |
    {2-3段话的结论详述，说明得出该结论的主要依据}
  
  conclusion_criteria_reference: |
    本结论依据以下判定标准：
    - "通过"：所有问题（含致命问题）均已解决或得到合理解释
    - "修改后通过"：致命问题已解决，重要问题已基本解决或导师认可当前方案
    - "修改后重审"：存在致命问题未解决，需修改后再次提交审核
    - "不通过"：致命问题未解决且无合理反驳依据，或研究方向存在根本性问题
  
  # ══════════════════════════════════════
  # 第二部分：逐条回应评估明细
  # ══════════════════════════════════════
  response_evaluation:
    - query_id: "Q-C01"
      original_severity: critical
      source_issue: "M-01"
      response_type: "接受"
      evaluation: "已解决"  # 已解决 / 部分解决 / 未解决 / 反驳成立 / 反驳不成立 / 补充有效 / 补充无效
      scores:
        targeting: 2
        sufficiency: 2
        evidence: 2
      total_score: 6
      comment: "学生补充了Transformer架构的选择依据及预实验结果，论证充分，具有说服力。"
    
    - query_id: "Q-C02"
      original_severity: critical
      source_issue: "C-01"
      response_type: "反驳"
      evaluation: "部分解决（问题降级）"
      scores:
        logic: 1
        evidence: 1
        doc_consistency: 2
      total_score: 4
      comment: "学生对'弱监督'概念的引用有一定道理，但概念转换不够严谨。
                原问题从critical降级为important，建议在修改稿中明确界定术语。"
    
    - query_id: "Q-I01"
      original_severity: important
      source_issue: "M-02"
      response_type: "接受"
      evaluation: "已解决"
      scores:
        targeting: 2
        sufficiency: 2
        evidence: 1
      total_score: 5
      comment: "消融实验方案已补充完整，评估基线也已明确。"
    
    - query_id: "Q-S01"
      original_severity: suggestion
      response_type: "未回应"
      evaluation: "豁免"
      comment: "建议性问题未回应，不影响审稿结论。"
  
  # ══════════════════════════════════════
  # 第三部分：遗留问题清单
  # ══════════════════════════════════════
  remaining_issues:
    - issue_id: "Q-C02（降级后）"
      severity: important
      description: "研究问题中'弱监督场景'与'小样本'的概念关系需进一步厘清"
      suggested_action: "在修改稿的研究问题或研究背景部分增加一段概念辨析"
      deadline: "论文正式写作前完成"
  
  # ══════════════════════════════════════
  # 第四部分：导师意见分析
  # ══════════════════════════════════════
  advisor_analysis:
    sentiment: "有条件认可"
    alignment_with_student: "基本一致"
    independent_points:
      - "导师同样关注'弱监督'与'小样本'的概念界定问题，建议采纳"
    divergence_note: "无重大分歧"
  
  # ══════════════════════════════════════
  # 第五部分：评分变化
  # ══════════════════════════════════════
  scoring:
    original_score: 72
    adjustments:
      - item: "解决 critical Q-C01"
        change: +5
      - item: "解决 important Q-I01"
        change: +3
      - item: "解决 suggestion（无）"
        change: 0
      - item: "Q-C02 反驳部分成立（降级）"
        change: +2
    final_score: 82
    level: "良好"  # 优秀/良好/一般/较差/不合格
  
  # ══════════════════════════════════════
  # 第六部分：下一步行动
  # ══════════════════════════════════════
  next_action: none  # none / require_revision / require_requery
  
  action_detail: |
    {根据 next_action 给出具体指引}
    # none: 流程结束
    # require_revision: 需针对遗留问题继续修改（无需再走完整质询流程）
    # require_requery: 进入下一轮质询循环
  
  # ══════════════════════════════════════
  # 第七部分：迭代信息
  # ══════════════════════════════════════
  iteration_info:
    current_round: 1
    max_rounds: 2
    can_iterate: true  # false 表示已达上限
    iteration_guidance: |
      {如果 can_iterate == true，给出是否建议进入下一轮的建议}
  
  # ══════════════════════════════════════
  # 元数据
  # ══════════════════════════════════════
  metadata:
    generated_at: "2026-06-05T14:00:00Z"
    document_title: "《基于深度学习的XXX研究》"
    reviewer_type: "AI复审专家"
```

---

## 输出文档规范

### 复审意见(版本).docx

除上述 YAML 结构化数据外，`AI_review` 须输出一份正式的 Word 文档 `复审意见(版本).docx`，供存档和正式提交使用。

**文档命名与存储规则**：
- 基础格式：`memory/复审意见(v{轮次}).docx`
- 示例：`memory/复审意见(v1).docx`、`memory/复审意见(v2).docx`
- 同一轮次多次修改：`memory/复审意见(v1-YYYYMMDD).docx`
- **存储路径**：所有复审意见书统一保存至 `memory/` 文件夹，与阶段六的中间文档保持一致

**文档内容结构**：

```
┌─────────────────────────────────────────┐
│           开题报告复审意见书              │
├─────────────────────────────────────────┤
│ 文档标题：{document_title}              │
│ 复审轮次：第 {current_round} 轮         │
│ 生成时间：{generated_at}                │
│ 复审专家：{reviewer_type}               │
├─────────────────────────────────────────┤
│                                         │
│ 一、审稿结论                            │
│   {conclusion_detail}                   │
│                                         │
│ 二、逐条回应评估                        │
│   {response_evaluation 逐项展开}        │
│                                         │
│ 三、遗留问题清单                        │
│   {remaining_issues}                    │
│                                         │
│ 四、导师意见分析                        │
│   {advisor_analysis}                    │
│                                         │
│ 五、评分变化                            │
│   原始评分：{original_score}            │
│   复审后评分：{final_score} ({level})   │
│                                         │
│ 六、下一步行动                          │
│   {action_detail}                       │
│                                         │
├─────────────────────────────────────────┤
│ 注：本意见书由 AI 复审系统生成，供评审  │
│    专家参考。如有异议，请以人工复审为准。 │
└─────────────────────────────────────────┘
```

**排版要求**：
- 标题：黑体，二号，居中
- 一级标题：黑体，三号
- 正文：宋体/仿宋，小四，1.5倍行距
- 表格：三线表格式
- 页眉："开题报告复审意见书 - 第X轮"
- 页脚：页码 + 生成时间戳

---

## 五、迭代机制详解

### 多轮复审的状态机

```
初始状态
  ↓
[第1轮质询] → [用户回应] → [第1轮复审]
  ↓                              ↓
 结论="通过"                   结论="修改后重审" 且 round < max
  ↓                              ↓
 结束                        [第2轮质询] → [用户回应] → [第2轮复审]
                                        ↓
                               结论=任意（强制结束）
```

### 第 N+1 轮质询的特殊处理

当进入第 2 轮（或更高轮次）质询时，`AI_professor` 应收到额外的上下文：

```yaml
iteration_context_for_next_round:
  previous_round_evaluation: "{上一轮 AI_review 的 response_evaluation}"
  remaining_issues_from_last_round: "{上一轮的 remaining_issues}"
  focus_instruction: |
    本轮质询应聚焦于以下情况：
    1. 上一轮判定为"部分解决"或"未解决"的问题——追问进展
    2. 上一轮判定为"反驳不成立"的问题——坚持原质疑，要求实质性修改
    3. 上一轮中新发现的衍生问题（如有）
    4. 不再重复上一轮已判定为"已解决"的问题
```

### 达到迭代上限时的处理

当 `current_round == max_rounds` 且结论仍为"修改后重审"或"不通过"：

1. 输出当前复审意见为**最终意见**（不再触发新一轮质询）。
2. 在 `action_detail` 中明确说明：
   > "已达到最大复审轮次（{max_rounds}轮）。当前意见为最终审稿意见。
   > 如需继续修改，建议重新整理开题报告后发起新一轮完整审稿流程。"
3. 列出所有仍未解决的问题，按优先级排序，作为"重新提交时的重点修改清单"。

---

## 六、异常处理

| 异常场景 | 处理方式 |
|---------|---------|
| 用户反馈格式不规范（缺少必要字段） | 拒绝处理，返回错误提示，列出缺失字段，暂停复审流程 |
| 用户反馈为空或仅有"已阅""同意"等无实质内容 | 判定为"未回应所有必答问题"，结论直接为"修改后重审" |
| 导师意见与学生回应严重矛盾 | 分别记录双方立场，以技术审查为准，在最终意见中注明分歧 |
| 修改后文档与回应描述不一致 | 指出不一致之处，要求核实，该问题判定为"部分解决" |
| 用户回应远超建议字数（如单条 > 2000 字） | 不拒绝，但在评估时关注回应是否聚焦，冗长本身不加分 |
| 质询报告中某条问题的 ID 在回应中找不到 | 按"未回应"处理，并在评估明细中标注 |

---

## 七、与其他子技能的数据依赖关系

```
┌─────────────────┐     ┌──────────────────┐     ┌────────────────┐
│  问题总结.docx   │────▶│   AI_professor   │────▶│  质询报告.docx  │
│  详细报告.docx   │     │  (阶段五调用)     │     │                │
│  一致性校验结果  │     └──────────────────┘     └───────┬────────┘
└─────────────────┘                                      │
                                                         ▼
┌─────────────────┐     ┌──────────────────┐     ┌────────────────┐
│  最终意见.docx   │◀────│    AI_review     │◀────│  用户反馈材料   │
│  (本技能输出)    │     │  (阶段七调用)     │     │  (学生+导师)    │
└─────────────────┘     └──────────────────┘     └────────────────┘
        ▲                       │
        │                       │
        └──── 前三轮文档全部传入 ─┘
```

---

## 八、自检清单

生成最终审稿意见后，执行以下自检：

| 检查项 | 通过标准 |
|--------|---------|
| 覆盖完整性 | 质询报告中每条 `require_response: true` 的问题都有评估结果 |
| 判定一致性 | `conclusion` 与判定矩阵的规则一致，无矛盾 |
| 评分合理性 | 最终评分在 [original_score - 10, original_score + 20] 区间内（极端情况除外） |
| 遗留问题清单 | 所有未解决/部分解决的问题都已列入 `remaining_issues` |
| 导师意见记录 | `advisor_opinion` 已被分析和引用，未被忽略 |
| 下一步指引 | `next_action` 与 `conclusion` 逻辑一致 |
| 迭代状态正确 | `can_iterate` 与 `current_round` / `max_rounds` 的关系正确 |
| 无遗漏必答问题 | 不存在 `require_response: true` 且无评估结果的质询条目 |
